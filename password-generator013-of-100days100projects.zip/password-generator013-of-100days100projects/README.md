# Password Generator - #013 of #100Days100Projects

A Pen created on CodePen.io. Original URL: [https://codepen.io/FlorinPop17/pen/BaBePej](https://codepen.io/FlorinPop17/pen/BaBePej).

This project is part of the #100Days100Projects challenge.

Check it out here: https://www.florin-pop.com/blog/2019/09/100-days-100-projects