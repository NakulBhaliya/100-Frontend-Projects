# Booking form with a calendar

A Pen created on CodePen.io. Original URL: [https://codepen.io/Shemetillo/pen/egOvBe](https://codepen.io/Shemetillo/pen/egOvBe).

